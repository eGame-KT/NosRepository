#include "DxLib.h"
#include "main.h"
#include "eki.h"

