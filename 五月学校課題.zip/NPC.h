//#pragma once


enum NPC_TYPE
{
	NPC_SINTOMO,
	NPC_J1,
	NPC_D1,
	NPC_MAX
};



void NPCsystemInito(void);
void ekiNPCInit(void);
void ekiNPCcontrol(void);
void NPCDraw(void);