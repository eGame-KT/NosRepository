//#pragma once








bool EkiSystemInit(void);
void EkiInitScene(void);
void SetEkiData(void);
void EkiDraw(void);
//void ekiNPCcontrol(void);
