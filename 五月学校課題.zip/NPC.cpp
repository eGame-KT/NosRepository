#include "DxLib.h"
#include "main.h"
#include "NPC.h"
#include "eki.h"


CHARACTER NPCType[NPC_MAX];
int NPCImage[NPC_MAX][12];
//int SinyuuImage[12];


void NPCsystemInito(void)
{
	if (LoadDivGraph("image/sinyuu.png", 12, 3, 4, 30, 42, NPCImage[NPC_SINTOMO]));
	if (LoadDivGraph("image/onnanoko1.png", 12, 3, 4, 30, 42, NPCImage[NPC_J1]));


	NPCType[NPC_J1].pos.x = 35;
	NPCType[NPC_J1].pos.y = 144;
	NPCType[NPC_J1].speed = 1;
	NPCType[NPC_J1].aniCnt = 0;
	NPCType[NPC_J1].moveDIR = DIR_RIGHT;
	NPCType[NPC_J1].moveCnt = 0;


	/*NPCType[NPC_SINTOMO].pos.x = 120;
	NPCType[NPC_SINTOMO].pos.y = 124;
	NPCType[NPC_SINTOMO].speed = 1;
	NPCType[NPC_SINTOMO].aniCnt = 0;
	NPCType[NPC_SINTOMO].moveDIR = DIR_RIGHT;
	NPCType[NPC_SINTOMO].moveCnt = 0;*/
}


void ekiNPCInit(void)
{
	NPCType[NPC_J1].pos.x = 35;
	NPCType[NPC_J1].pos.y = 144;
	NPCType[NPC_J1].speed = 1;
	NPCType[NPC_J1].aniCnt = 0;
	NPCType[NPC_J1].moveDIR = DIR_RIGHT;
	NPCType[NPC_J1].moveCnt = 0;
}

void ekiNPCcontrol(void)
{
	// ���E�ړ��e�X�g
	if (NPCType[NPC_J1].moveDIR == DIR_RIGHT)
	{
		if (NPCType[NPC_J1].pos.x <= 156)
		{
			NPCType[NPC_J1].pos.x += NPCType[NPC_J1].speed;
			NPCType[NPC_J1].aniCnt++;
		}
		else
		{
			NPCType[NPC_J1].Cnt++;
			if (NPCType[NPC_J1].Cnt >= 120)
			{
				NPCType[NPC_J1].moveDIR = DIR_LEFT;
				NPCType[NPC_J1].Cnt = 0;
			}

		}
	}
	else if (NPCType[NPC_J1].moveDIR == DIR_LEFT)
	{

		if (NPCType[NPC_J1].pos.x >= 35)
		{
			NPCType[NPC_J1].pos.x -= NPCType[NPC_J1].speed;
			NPCType[NPC_J1].aniCnt++;
		}
		else
		{
			NPCType[NPC_J1].Cnt++;
			if (NPCType[NPC_J1].Cnt >= 120)
			{
				NPCType[NPC_J1].moveDIR = DIR_RIGHT;
				NPCType[NPC_J1].Cnt = 0;
			}
		}
	}

	// �㉺�ړ��e�X�g
	if (NPCType[NPC_J1].moveDIR == DIR_DOWN)
	{
		if (NPCType[NPC_J1].pos.y <= 400)
		{
			NPCType[NPC_J1].pos.y += NPCType[NPC_J1].speed;
		}
		else
		{
			NPCType[NPC_J1].Cnt++;
			if (NPCType[NPC_J1].Cnt >= 120)
			{
				NPCType[NPC_J1].moveDIR = DIR_UP;
				NPCType[NPC_J1].Cnt = 0;
			}
		}
	}
	else if (NPCType[NPC_J1].moveDIR == DIR_UP)
	{
		if (NPCType[NPC_J1].pos.y >= 200)
		{
			NPCType[NPC_J1].pos.y -= NPCType[NPC_J1].speed;

		}
		else
		{
			NPCType[NPC_J1].Cnt++;
			if (NPCType[NPC_J1].Cnt >= 120)
			{
				NPCType[NPC_J1].moveDIR = DIR_DOWN;
				NPCType[NPC_J1].Cnt = 0;
			}
		}
	}

	

}

void NPCDraw(void)
{
	DrawGraph(NPCType[NPC_J1].pos.x, NPCType[NPC_J1].pos.y,
		NPCImage[NPC_J1][NPCType[NPC_J1].moveDIR * 3 + (NPCType[NPC_J1].aniCnt / 20 % 3)], true);
}