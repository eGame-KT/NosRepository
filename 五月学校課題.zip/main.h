//#pragma once



#define SCREEN_SIZE_X 640	//��ʻ��މ�
#define SCREEN_SIZE_Y 480	//��ʻ��ޏc



struct XY
{
	int x;
	int y;
};

enum DIR
{
	DIR_DOWN,
	DIR_LEFT,
	DIR_RIGHT,
	DIR_UP,
	DIR_MAX
};


struct CHARACTER
{
	XY pos;
	DIR moveDIR;
	int Cnt;
	int aniCnt;
	int moveCnt;
	int speed;
};

enum SCENE_ID {
	SCENE_ID_INIT,				//�ްя��������
	SCENE_ID_TITLE,			//���ټ��
	SCENE_ID_GAME,				//�ްѼ��
	SCENE_ID_GAMEOVER,			//�ްѵ��ް���
	SCENE_ID_MAX
};

enum STAGE_ID
{
	STAGE_ID_HEYA,
	STAGE_ID_EKI,
	STAGE_ID_MAX
};

enum EVENT_ID 
{
	EVENT_ID_NON,
	EVENT_ID_TALK,
	EVENT_ID_MAX
};


bool SystemInit(void);
void InitScene(void);
void TitleScene(void);
void TitleDraw(void);
void GameMain(void);
void SetEkiData(void);
void GameDraw(void);
void EventDraw(void);
//void ekiNPCcontrol(void);
